#ifndef TP1_H
#define	TP1_H
#include <stdio.h>
#include <stdlib.h>

long long int **alocarmatriz (long long int cartastotal);
long long int dinamico (long long int *cartas, long long int cartastotal);


#endif