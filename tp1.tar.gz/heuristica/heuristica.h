#ifndef HEURISTICA_H
#define	HEURISTICA_H
#include <stdio.h>
#include <stdlib.h>


long long int heuristica (long long int *cartas,long long int cartastotal);

#endif


